hey needs to wkrk like

la

launch app

la appname

donf add them to bashrc yet llease test first rjght remenber 
